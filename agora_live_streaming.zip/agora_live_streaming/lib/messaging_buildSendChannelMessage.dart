Widget _buildSendChannelMessage() {
  if (!_isLogin || !_isInChannel) {
    return Container();
  }
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: <Widget>[
      Container(
        width: MediaQuery.of(context).size.width * 0.75,
        child: TextFormField(
          showCursor: true,
          enableSuggestions: true,
          textCapitalization: TextCapitalization.sentences,
          controller: _channelMessageController,
          decoration: InputDecoration(
            hintText: 'Comment...',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
              borderSide: BorderSide(color: Colors.grey, width: 2),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
              borderSide: BorderSide(color: Colors.grey, width: 2),
            ),
          ),
        ),
      ),
      Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(40)),
            border: Border.all(
              color: Colors.blue,
              width: 2,
            )),
        child: IconButton(
          icon: Icon(Icons.send, color: Colors.blue),
          onPressed: _toggleSendChannelMessage,
        ),
      )
    ],
  );
}
