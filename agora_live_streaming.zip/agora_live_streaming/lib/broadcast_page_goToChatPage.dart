void _goToChatPage() {
  Navigator.of(context).push(
    MaterialPageRoute(
      builder: (context) => RealTimeMessaging(
        channelName: widget.channelName,
        userName: widget.username,
        isBroadcaster: widget.isBroadcaster,
      ),)
    );
}