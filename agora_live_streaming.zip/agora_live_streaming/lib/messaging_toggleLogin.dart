void _toggleLogin() async {
  if (!_isLogin) {
    try {
      await _client.login(null, widget.userName);
      print('Login success: ' + widget.userName);
      setState(() {
        _isLogin = true;
      });
    } catch (errorCode) {
      print('Login error: ' + errorCode.toString());
    }
  }
}
