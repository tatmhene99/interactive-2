void _toggleSendChannelMessage() async {
  String text = _channelMessageController.text;
  if (text.isEmpty) {
    print('Please input text to send.');
    return;
  }
  try {
    await _channel.sendMessage(AgoraRtmMessage.fromText(text));
    _log(text);
    _channelMessageController.clear();
  } catch (errorCode) {
    print('Send channel message error: ' + errorCode.toString());
  }
}
