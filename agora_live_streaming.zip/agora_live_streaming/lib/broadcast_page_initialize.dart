Future<void> initialize() async {
  print('Client Role: ${widget.isBroadcaster}');
  if (appId.isEmpty) {
    setState(() {
      _infoStrings.add(
        'APP_ID missing, please provide your APP_ID in settings.dart',
      );
      _infoStrings.add('Agora Engine is not starting');
    });
    return;
  }
  await _initAgoraRtcEngine();
  _addAgoraEventHandlers();
  await _engine.joinChannel(null, widget.channelName, null, 0);
}
