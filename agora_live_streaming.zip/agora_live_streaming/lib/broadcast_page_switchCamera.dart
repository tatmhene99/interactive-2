void _onSwitchCamera() {
  _engine.switchCamera();
}