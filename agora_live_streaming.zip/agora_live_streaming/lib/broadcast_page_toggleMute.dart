void _onToggleMute() {
  setState((){
    muted = !muted;
  });
  _engine.muteLocalAudioStream(muted);
}