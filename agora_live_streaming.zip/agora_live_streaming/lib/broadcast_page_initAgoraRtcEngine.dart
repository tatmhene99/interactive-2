Future<void> _initAgoraRtcEngine() async {
  _engine = await RtcEngine.create(appId);
  await _engine.enableVideo();
  await _engine.setChannelProfile(ChannelProfile.LiveBroadcasting);
  if (widget.isBroadcaster) {
    await _engine.setClientRole(ClientRole.Broadcaster);
  } else {
    await _engine.setClientRole(ClientRole.Audience);
  }
}