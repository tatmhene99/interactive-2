Widget _buildInfoList() {
  return Expanded(
      child: Container(
          child: _infoStrings.length > 0
              ? ListView.builder(
            reverse: true,
            itemBuilder: (context, i) {
              return Container(
                child: ListTile(
                  title: Align(
                    alignment: _infoStrings[i].startsWith('%')
                        ? Alignment.bottomLeft
                        : Alignment.bottomRight,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                      color: Colors.grey,
                      child: Column(
                        crossAxisAlignment: _infoStrings[i].startsWith('%') ?  CrossAxisAlignment.start : CrossAxisAlignment.end,
                        children: [
                          _infoStrings[i].startsWith('%')
                              ? Text(
                            _infoStrings[i].substring(1),
                            maxLines: 10,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.right,
                            style: TextStyle(color: Colors.black),
                          )
                              : Text(
                            _infoStrings[i],
                            maxLines: 10,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.right,
                            style: TextStyle(color: Colors.black),
                          ),
                          Text(
                            widget.userName,
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontSize: 10,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
            itemCount: _infoStrings.length,
          )
              : Container()));
}
