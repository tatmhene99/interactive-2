void _createClient() async {
  _client = await AgoraRtmClient.createInstance(appId);
  _client.onMessageReceived = (AgoraRtmMessage message, String peerId) {
    _logPeer(message.text);
  };
  _client.onConnectionStateChanged = (int state, int reason) {
    print('Connection state changed: ' +
        state.toString() +
        ', reason: ' +
        reason.toString());
    if (state == 5) {
      _client.logout();
      print('Logout.');
      setState(() {
        _isLogin = false;
      });
    }
  };

  _toggleLogin();
  _toggleJoinChannel();
}
