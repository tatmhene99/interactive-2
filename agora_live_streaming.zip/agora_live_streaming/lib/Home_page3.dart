Future<void> _handlerCameraAndMIc(Permission permission) async {
  final status = await permission.request();
  print(status);
}