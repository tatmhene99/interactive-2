void _toggleJoinChannel() async {
  try {
    _channel = await _createChannel(widget.channelName);
    await _channel.join();
    print('Join channel success.');

    setState(() {
      _isInChannel = true;
    });
  } catch (errorCode) {
    print('Join channel error: ' + errorCode.toString());
  }
}
