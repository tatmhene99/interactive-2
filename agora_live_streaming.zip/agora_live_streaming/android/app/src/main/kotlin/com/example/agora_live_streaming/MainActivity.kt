package com.example.agora_live_streaming

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
